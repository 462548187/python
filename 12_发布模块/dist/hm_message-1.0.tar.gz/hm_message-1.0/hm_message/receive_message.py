#! /usr/bin/env python
# -*- coding: utf-8 -*-
"""
    @Author         :  Sandy
    @Version        :  
  ----------------------------------
    @File           :  receive_message.py
    @Description    :  
    @CreateTime     :  2020/3/15 5:55 下午
    @Software       :  PyCharm
  -----------------------------------
    @ModifyTime     : 
"""


def receive():
    return "这是来之 100XX 的短信"
