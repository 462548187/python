#! /usr/bin/env python
# -*- coding: utf-8 -*-
"""
    @Author         :  Sandy
    @Version        :  
  ----------------------------------
    @File           :  send_message.py
    @Description    :  
    @CreateTime     :  2020/3/15 5:55 下午
    @Software       :  PyCharm
  -----------------------------------
    @ModifyTime     : 
"""


def send(text):
    print("正在方式 %s" % text)

